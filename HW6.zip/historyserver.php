<?php
$query = $_GET['q'];

if (strpos($query, 'XPn') === 0){
echo("It's Time to Choose a Major");
} else {
echo("Have you Considered:");
}
?>

<br/><br/>

<?php
if (strpos($query, 'L')){
echo("Art History");
echo("\n");
}
?>

<br/><br/>

<?php
if (strpos($query, '0')){
echo("Chemistry\r\n");
}
?>

<br/><br/>

<?php
if (strpos($query, 'b')){
echo("Economics\n");
}
?>

<br/><br/>

<?php
if (strpos($query, 'T')){
echo("English\n");
}
?>

<br/><br/>

<?php
if (strpos($query, '6')){
echo("Mathematics\n");
}
?>

<br/><br/>

<?php
if (strpos($query, 'Z')){
echo("Physics\n");
}
?>
